package com.example.app8;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

public class OcrActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_ocr);
    }
}